package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectTest01Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectTest01Application.class, args);
	}

}
